package sam.dayan.acronym.viewModels

import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel
import sam.dayan.acronym.networking.AcronymRepository

class AcronymViewModel: ViewModel() {

    var description = ObservableField<String>("The abbreviation meanings go here.")
    val repository = AcronymRepository()


    fun lookUp(abbreviation: String) {
        if (abbreviation.isEmpty()) {
            description.set("Please enter some text to get meanings for.")
            return
        }

        try {
            val acronym = repository.getAcronym(abbreviation)
            val meanings = mutableSetOf<String>()
            for (meaning in acronym?.get(0)?.lfs!!) {
                meaning.lf?.let { meanings.add(it) }
            }

            description.set(meanings.toString())
        } catch (e: Exception) {
            description.set("There was as issue retrieving meaning of abbreviation: ${abbreviation}.")
        }
    }
}