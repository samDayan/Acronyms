package sam.dayan.acronym

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query
import sam.dayan.acronym.networking.SamAcronym

interface AcronymService {

    @GET("dictionary.py")
    fun getAcronyms(
        @Query("sf")
    sf: String): Call<List<SamAcronym>>
}