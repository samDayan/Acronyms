package sam.dayan.acronym.networking

import com.google.gson.annotations.SerializedName


data class SamAcronym (

  @SerializedName("sf"  ) var sf  : String?        = null,
  @SerializedName("lfs" ) var lfs : ArrayList<Lfs> = arrayListOf()

)