package sam.dayan.acronym


import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView.OnEditorActionListener
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import sam.dayan.acronym.databinding.ActivityMainBinding
import sam.dayan.acronym.viewModels.AcronymViewModel


class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    lateinit var mViewModel : AcronymViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        mViewModel = AcronymViewModel()
        binding.vm = mViewModel

        /**
         * This is so that the user may look up abbreviation simply
         * by pressing the done button on the
         * keyboard instead of the "Look Upp Abbreviation" button.
         */
        binding.abbreviation.setOnEditorActionListener(OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                lookUp(v)
                return@OnEditorActionListener true
            }
            false
        })
    }

    public fun lookUp(view: View) {
        mViewModel.lookUp(binding.abbreviation.text.toString())
    }
}