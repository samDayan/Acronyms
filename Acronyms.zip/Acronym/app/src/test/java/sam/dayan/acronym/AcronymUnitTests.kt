package sam.dayan.acronym

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import sam.dayan.acronym.viewModels.AcronymViewModel

class AcronymUnitTests {

    private lateinit var viewModel: AcronymViewModel

    @Before
    fun setUp() {
        viewModel = AcronymViewModel()
    }

    @Test
    fun testNoAbbreviation() {
        viewModel.lookUp("")
        assertEquals("Please enter some text to get meanings for.", viewModel.description.get())
    }
}